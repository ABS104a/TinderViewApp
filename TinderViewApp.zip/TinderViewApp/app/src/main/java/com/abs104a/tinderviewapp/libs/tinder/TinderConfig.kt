package com.abs104a.tinderviewapp.libs.tinder

open class TinderConfig protected constructor(val duration: Long, val rotate: Float) {

    // TODO ConfigをTinderFragmentに適用させる．
    class ConfigBuilder {

        private val DEFAULT_DURTATION: Long = 400
        private val DEFAULT_ROTATE = 90f

        private var duration : Long = DEFAULT_DURTATION
        private var rotate : Float = DEFAULT_ROTATE

        fun setDurtation(duration: Long): ConfigBuilder {
            this.duration = duration
            return this
        }

        fun setRotate(rotate: Float): ConfigBuilder {
            this.rotate = rotate
            return this
        }

        fun build(): TinderConfig {
            val config = TinderConfig(duration,rotate)
            return config
        }
    }
}