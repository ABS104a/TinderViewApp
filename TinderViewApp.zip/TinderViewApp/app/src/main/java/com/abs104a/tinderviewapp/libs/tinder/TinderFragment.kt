package com.abs104a.tinderviewapp.libs.tinder

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.abs104a.tinderviewapp.R
import java.util.*

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [TinderFragment.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [TinderFragment.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class TinderFragment<T> : Fragment() {
    companion object {
        const val TAG = "TinderFragment"
    }

    private var listener: OnTinderInteractionListener<T> = object : OnTinderInteractionListener<T> {
        override fun getItemView(obj: T, viewGroup: ViewGroup) {
            // notthing
        }

        override fun onSwipe(state: Int, obj: T, view: View) {
            // notthing
        }

        override fun onSwiped(state: Int, obj: T, view: View) {
            // notthing
        }

        override fun onChangeSwipingStatus(state: Int, obj: T, view: View) {
            // notthing
        }

    }
    private var frameLayout: FrameLayout? = null;
    private var items: ArrayList<T> = ArrayList();

    // デフォルトのConfigを追加
    private var config : TinderConfig = TinderConfig.ConfigBuilder().build()

    // 画面外に行くアニメーション時間
    private val MOVE_TIME_TH: Int = 16
    private val MOVE_TH: Int = 5
    private val JUDGE_TH = 0.25

    val STATE_NONE = 0
    val STATE_TOP = 1
    val STATE_BOTTOM = 2
    val STATE_RIGHT = 3
    val STATE_LEFT = 4

    private var moveFlag = 0

    private var oldState = STATE_NONE

    private val touchListener = object : View.OnTouchListener {

        private var targetLocalX: Int = 0
        private var targetLocalY: Int = 0

        private var screenX: Float = 0f
        private var screenY: Float = 0f

        override fun onTouch(target: View?, event: MotionEvent?): Boolean {
            // onTouch
            if (event == null || target == null) return true
            val x = event.getRawX()
            val y = event.getRawY()

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {

                    targetLocalX = target.left
                    targetLocalY = target.top

                    screenX = x
                    screenY = y

                    moveFlag = 0

                    if (frameLayout != null) {
                        if (items.size == 0) {
                            frameLayout!!.getChildAt(0).visibility = View.GONE
                            frameLayout!!.getChildAt(1).visibility = View.GONE
                        } else if (items.size == 1) {
                            frameLayout!!.getChildAt(0).visibility = View.GONE
                            frameLayout!!.getChildAt(1).visibility = View.VISIBLE
                        } else {
                            frameLayout!!.getChildAt(0).visibility = View.VISIBLE
                            frameLayout!!.getChildAt(1).visibility = View.VISIBLE
                        }
                    }
                }

                MotionEvent.ACTION_MOVE -> {
                    // タッチ中
                    val diffX = screenX - x
                    val diffY = screenY - y

                    targetLocalX -= diffX.toInt()
                    targetLocalY -= diffY.toInt()

                    target.translationX = targetLocalX.toFloat()
                    target.translationY = targetLocalY.toFloat()
                    target.rotation = ((targetLocalX.toFloat() / target.width.toFloat()) + (targetLocalY.toFloat() / target.height.toFloat())) * config.rotate

                    screenX = x
                    screenY = y

                    if (moveFlag < MOVE_TH) moveFlag = moveFlag + 1

                    // ステート
                    if (targetLocalX > target.width * JUDGE_TH) {
                        if (oldState != STATE_RIGHT){
                            listener.onChangeSwipingStatus(STATE_RIGHT, items[0],target)
                            oldState = STATE_RIGHT
                        }
                    } else if (0 - targetLocalX > target.width * JUDGE_TH) {
                        if (oldState != STATE_LEFT){
                            listener.onChangeSwipingStatus(STATE_LEFT, items[0],target)
                            oldState = STATE_LEFT
                        }
                    } else if (targetLocalY > target.height * JUDGE_TH) {
                        if (oldState != STATE_BOTTOM){
                            listener.onChangeSwipingStatus(STATE_BOTTOM, items[0],target)
                            oldState = STATE_BOTTOM
                        }
                    } else if (0 - targetLocalY > target.height * JUDGE_TH) {
                        if (oldState != STATE_TOP) {
                            listener.onChangeSwipingStatus(STATE_TOP, items[0],target)
                            oldState = STATE_TOP
                        }
                    } else if (oldState != STATE_NONE){
                        listener.onChangeSwipingStatus(STATE_NONE, items[0],target)
                        oldState = STATE_NONE
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_OUTSIDE -> {

                    if (event.action == MotionEvent.ACTION_UP &&
                            moveFlag < MOVE_TIME_TH &&
                            Math.abs(targetLocalX + targetLocalY) < MOVE_TH) {
                        // クリックイベントの処理
                        target.performClick()
                    }
                    moveFlag = 0

                    // 動作判定（Viewの1/3以上動いたらそれぞれの動作として見なす）
                    if (getTopView() != target){
                        // キャンセル
                        viewAnimation(target, 0f - target.left, 0f - target.top, 0f ,Runnable{
                            listener.onSwiped(STATE_NONE, items[0],target)
                        })
                        listener.onSwipe(STATE_NONE, items[0],target)
                    } else if (targetLocalX > target.width * JUDGE_TH) {
                        // 右
                        val item = items.removeAt(0)
                        listener.onSwipe(STATE_RIGHT,item,target)
                        val margin = if (target.width < target.height) target.height - target.width else 0
                        viewAnimation(target, (target.width + margin).toFloat(), ((target.width * targetLocalY) / targetLocalX).toFloat(), config.rotate,Runnable {
                            listener.onSwiped(STATE_RIGHT,item,target)
                            changeCard()
                        })
                    } else if (0 - targetLocalX > target.width * JUDGE_TH) {
                        // 左
                        val item = items.removeAt(0)
                        listener.onSwipe(STATE_LEFT,item,target)
                        val margin = if (target.width < target.height) target.height - target.width else 0
                        viewAnimation(target, (0 - target.width - margin).toFloat(), ((target.width * targetLocalY) / (0 - targetLocalX)).toFloat(),0 - config.rotate, Runnable {
                            listener.onSwiped(STATE_LEFT,item,target)
                            changeCard()
                        })
                    } else if (targetLocalY > target.height * JUDGE_TH) {
                        // 下
                        val item = items.removeAt(0)
                        listener.onSwipe(STATE_BOTTOM,item,target)
                        val margin = if (target.width < target.height) 0 else target.width - target.height
                        viewAnimation(target, ((target.height * targetLocalX) / targetLocalY).toFloat(), (target.height + margin).toFloat(),config.rotate, Runnable {
                            listener.onSwiped(STATE_BOTTOM,item,target)
                            changeCard()
                        })
                    } else if (0 - targetLocalY > target.height * JUDGE_TH) {
                        // 上
                        val item = items.removeAt(0)
                        listener.onSwipe(STATE_TOP,item,target)
                        val margin = if (target.width < target.height) 0 else target.width - target.height
                        viewAnimation(target, ((target.height * targetLocalX) / (0 - targetLocalY)).toFloat(), (0 - target.height - margin).toFloat(),0 - config.rotate, Runnable {
                            listener.onSwiped(STATE_TOP,item,target)
                            changeCard()
                        })
                    } else {
                        // キャンセルされた時
                        viewAnimation(target, 0f - target.left, 0f - target.top,0f, Runnable{
                            listener.onSwiped(STATE_NONE, items[0],target)
                        })
                        listener.onSwipe(STATE_NONE, items[0],target)
                    }
                    // リセットする．
                    screenX = 0f
                    screenY = 0f
                    targetLocalX = 0
                    targetLocalY = 0
                    oldState = STATE_NONE
                }
            }
            return true
        }
    }

    protected fun changeCard() {
        swapView()
        if (frameLayout != null) {
            if (items.size >= 2) {
                listener.getItemView(items.get(1), frameLayout!!.getChildAt(0) as ViewGroup)
            } else if (items.size == 0) {
                frameLayout!!.getChildAt(0).visibility = View.GONE
                frameLayout!!.getChildAt(1).visibility = View.GONE
            }
        }
    }


    /**
     * ViewをAnimationさせる
     */
    protected fun viewAnimation(target: View, toX: Float, toY: Float,rotate: Float, callback: Runnable?) {
        target.animate()
                .translationX(toX)
                .translationY(toY)
                .rotation(rotate)
                .setDuration(config.duration)
                .withEndAction(callback)
                .start()
    }

    /**
     * TinderEventListenerのセット
     */
    fun setOnTinderInteractionListener(listener: OnTinderInteractionListener<T>) {
        this.listener = listener
    }

    /**
     * 設定の追加
     */
    fun setTinderConfig(config: TinderConfig){
        this.config = config
    }

    fun addItem(obj: T) {
        items.add(obj)
    }

    fun addItem(pos: Int, obj: T) {
        items.add(pos, obj)

        if (items.size == 1) {
            frameLayout!!.getChildAt(0).visibility = View.VISIBLE
        } else if (items.size == 2) {
            frameLayout!!.getChildAt(1).visibility = View.VISIBLE
            frameLayout!!.getChildAt(0).visibility = View.VISIBLE
        }

        if (pos == 0) {
            // 1番目の場合（Initして表示を良い感じに）
            swapView()
            val target = frameLayout!!.getChildAt(1);
            listener.getItemView(items[pos], target as ViewGroup)
            val margin = if (target.width > target.height) target.width - target.height else 0
            target.translationY = (target.height + margin).toFloat()
            target.rotation = config.rotate
            viewAnimation(target, 0f, 0f, 0f,null)
        } else if (pos == 1) {
            // 2番目の場合（間書き換える）
            listener.getItemView(items.get(pos), frameLayout!!.getChildAt(0) as ViewGroup)
        }
    }

    fun getSize(): Int {
        return items.size
    }

    protected fun swapView() {
        val swapView = frameLayout!!.getChildAt(1)
        swapView.translationX = 0f
        swapView.translationY = 0f
        swapView.rotation = 0f
        frameLayout!!.removeViewAt(1)
        frameLayout!!.addView(swapView, 0)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        frameLayout = inflater.inflate(R.layout.fragment_tinder, container, false) as FrameLayout;
        initView(frameLayout as ViewGroup)
        return frameLayout
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
    }

    override fun onDetach() {
        super.onDetach()
    }

    protected fun initView(viewGroup: ViewGroup) {
        if (items.size == 0) {
            viewGroup.getChildAt(1).visibility = View.INVISIBLE
            viewGroup.getChildAt(0).visibility = View.INVISIBLE
        } else if (items.size == 1) {
            viewGroup.getChildAt(1).visibility = View.VISIBLE
            viewGroup.getChildAt(0).visibility = View.INVISIBLE
            listener.getItemView(items[0], viewGroup.getChildAt(0) as ViewGroup)
        } else {
            viewGroup.getChildAt(1).visibility = View.VISIBLE
            viewGroup.getChildAt(0).visibility = View.VISIBLE
            listener.getItemView(items[0], viewGroup.getChildAt(1) as ViewGroup)
            listener.getItemView(items[1], viewGroup.getChildAt(0) as ViewGroup)
        }
        viewGroup.getChildAt(0).setOnTouchListener(touchListener)
        viewGroup.getChildAt(1).setOnTouchListener(touchListener)
    }

    fun notifiyDataSetChanged() {
        initView(frameLayout as ViewGroup)
    }

    fun getTopView(): ViewGroup {
        return frameLayout!!.getChildAt(1) as ViewGroup
    }

    fun getTopItem(): T {
        return items[0];
    }

    interface OnTinderInteractionListener<T> {
        fun getItemView(obj: T, viewGroup: ViewGroup)
        fun onSwipe(state: Int, obj: T, view: View)
        fun onSwiped(state: Int, obj: T, view: View)
        fun onChangeSwipingStatus(state: Int, obj: T, view: View)
    }
}
